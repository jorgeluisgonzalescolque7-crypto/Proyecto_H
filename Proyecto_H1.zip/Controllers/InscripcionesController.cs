﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proyecto_H.Data;
using Proyecto_H.Dominio;

namespace Proyecto_H.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InscripcionesController : ControllerBase
    {
        private readonly HospitalContext _context;

        public InscripcionesController(HospitalContext context)
        {
            _context = context;
        }

        // Lista completa
        [HttpGet]
        public async Task<IActionResult> GetInscripciones()
        {
            return Ok(
                await (
                    from i in _context.Inscripcion
                    where i.Estado != "Inactivo"
                    select new
                    {
                        i.Codigo,
                        i.IdUsuario,
                        i.IdCapacitacion,
                        i.FechaInscripcion
                    }
                ).ToListAsync()
            );
        }

        // JOIN 3 tablas
        [HttpGet("Query")]
        public async Task<IActionResult> Query()
        {
            var query = await (
                from u in _context.Usuario
                join i in _context.Inscripcion
                   on u.IdUsuario equals i.IdUsuario
                join c in _context.Capacitacion
                   on i.IdCapacitacion equals c.IdCapacitacion
                where i.Estado != "Inactivo"
                select new
                {
                    Usuario = u.Nombre,
                    Capacitacion = c.Nombre,
                    FechaInscripcion = i.FechaInscripcion
                }
            ).ToListAsync();

            return Ok(query);
        }

        //JOIN 2 TABLAS
        [HttpGet("QueryDosTablas")]
        public async Task<IActionResult> QueryDosTablas()
        {
            var query = await (
              from u in _context.Usuario
              join i in _context.Inscripcion
              on u.IdUsuario equals i.IdUsuario
              where i.Estado != "Inactivo"
              select new
              {
                  Usuario = u.Nombre,
                  CodigoInscripcion = i.Codigo
              }
            ).ToListAsync();

            return Ok(query);
        }

        // crear relación por códigos
        [HttpPost("crear")]
        public async Task<IActionResult> PostInscripcion(
            string codigoUsuario,
            string codigoCapacitacion
        )
        {
            Usuario? usuario = await (
                from u in _context.Usuario
                where u.Codigo == codigoUsuario
                select u
            ).FirstOrDefaultAsync();

            Capacitacion? cap = await (
                from c in _context.Capacitacion
                where c.Codigo == codigoCapacitacion
                select c
            ).FirstOrDefaultAsync();

            if (usuario == null || cap == null)
                return BadRequest("No encontrado");

            Inscripcion? existe = await (
                from i in _context.Inscripcion
                where i.IdUsuario == usuario.IdUsuario
                && i.IdCapacitacion == cap.IdCapacitacion
                select i
            ).FirstOrDefaultAsync();

            if (existe != null)
                return BadRequest("Ya existe relación");

            Inscripcion ins = new()
            {
                Codigo = "INS" + DateTime.Now.ToString("yyyyMMddHHmmss"),
                IdUsuario = usuario.IdUsuario,
                IdCapacitacion = cap.IdCapacitacion,
                FechaInscripcion = DateTime.UtcNow,
                Estado = "Activo"
            };

            _context.Inscripcion.Add(ins);

            await _context.SaveChangesAsync();

            return Ok("Inscripción creada");
        }

        // soft delete relación
        [HttpDelete("{codigo}")]
        public async Task<IActionResult> DeleteInscripcion(
            string codigo
        )
        {
            Inscripcion? ins = await (
                from i in _context.Inscripcion
                where i.Codigo == codigo
                select i
            ).FirstOrDefaultAsync();

            if (ins == null)
                return NotFound();

            ins.Estado = "Inactivo";

            _context.Inscripcion.Update(ins);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}