﻿using Microsoft.EntityFrameworkCore;
using Proyecto_H.Dominio;

namespace Proyecto_H.Data
{
    public class HospitalContext : DbContext
    {
        public HospitalContext(
            DbContextOptions<HospitalContext> options
        ) : base(options)
        {

        }

        public DbSet<Usuario> Usuario { get; set; } = default!;

        public DbSet<Capacitacion> Capacitacion { get; set; } = default!;

        public DbSet<Inscripcion> Inscripcion { get; set; } = default!;
    }
}