﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proyecto_H.Data;
using Proyecto_H.Dominio;

namespace Proyecto_H.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CapacitacionesController : ControllerBase
    {
        private readonly HospitalContext _context;

        public CapacitacionesController(HospitalContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetCapacitaciones()
        {
            return Ok(
                await (
                    from c in _context.Capacitacion
                    where c.Estado != "Inactivo"
                    select new
                    {
                        c.Codigo,
                        c.Nombre
                    }
                ).ToListAsync()
            );
        }

        [HttpGet("{codigo}")]
        public async Task<IActionResult> GetCapacitacion(string codigo)
        {
            Capacitacion? cap = await (
                from c in _context.Capacitacion
                where c.Codigo == codigo
                select c
            ).FirstOrDefaultAsync();

            if (cap == null)
                return NotFound();

            return Ok(new
            {
                cap.Codigo,
                cap.Nombre
            });
        }

        [HttpPost]
        public async Task<IActionResult> PostCapacitacion(
    string nombre
)
        {
            string codigoGenerado =
               "CAP" + DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");

            Capacitacion c1 = new()
            {
                Codigo = codigoGenerado,
                Nombre = nombre,
                Estado = "Activo"
            };

            _context.Capacitacion.Add(c1);

            await _context.SaveChangesAsync();

            return Ok("Creada");
        }

        [HttpPut("{codigo}")]
        public async Task<IActionResult> PutCapacitacion(
            string codigo,
            string nombre
        )
        {
            Capacitacion? cap = await (
                from c in _context.Capacitacion
                where c.Codigo == codigo
                select c
            ).FirstOrDefaultAsync();

            if (cap == null)
                return NotFound();

            cap.Nombre = nombre;

            _context.Capacitacion.Update(cap);

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{codigo}")]
        public async Task<IActionResult> DeleteCapacitacion(
            string codigo
        )
        {
            Capacitacion? cap = await (
                from c in _context.Capacitacion
                where c.Codigo == codigo
                select c
            ).FirstOrDefaultAsync();

            if (cap == null)
                return NotFound();

            cap.Estado = "Inactivo";

            _context.Capacitacion.Update(cap);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}