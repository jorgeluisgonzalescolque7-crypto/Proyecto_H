﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proyecto_H.Data;
using Proyecto_H.Dominio;

namespace Proyecto_H.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        // conexión al DbContext
        private readonly HospitalContext _context;

        public UsuariosController(HospitalContext context)
        {
            _context = context;
        }

        // GET: api/Usuarios
        // Lista solo usuarios activos
        [HttpGet]
        public async Task<IActionResult> GetUsuarios()
        {
            return Ok(
                await (
                    from u in _context.Usuario
                    where u.Estado != "Inactivo"
                    select new
                    {
                        u.Codigo,
                        u.Nombre,
                        u.Apellido
                    }
                ).ToListAsync()
            );
        }

        // GET api/Usuarios/U001
        // Buscar por código
        [HttpGet("{codigo}")]
        public async Task<IActionResult> GetUsuario(string codigo)
        {
            var usuario = await (
                from u in _context.Usuario
                where u.Codigo == codigo
                select u
            ).FirstOrDefaultAsync();

            if (usuario == null)
                return NotFound();

            return Ok(new
            {
                usuario.Codigo,
                usuario.Nombre,
                usuario.Apellido
            });
        }

        // POST api/Usuarios
        // Crear usuario
        [HttpPost]
        public async Task<IActionResult> PostUsuario(
            string nombre,
            string apellido
        )
        {
            string codigoGenerado =
                "USR" + DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");

            Usuario u = new Usuario()
            {
                Codigo = codigoGenerado,
                Nombre = nombre,
                Apellido = apellido,
                Estado = "Activo"
            };

            _context.Usuario.Add(u);

            await _context.SaveChangesAsync();

            return Ok("Creado correctamente");
        }

        // PUT api/Usuarios/U001
        // Actualizar usando código (no id)
        [HttpPut("{codigo}")]
        public async Task<IActionResult> PutUsuario(
            string codigo,
            string nombre,
            string apellido
        )
        {
            var usuario = await (
                from u in _context.Usuario
                where u.Codigo == codigo
                select u
            ).FirstOrDefaultAsync();

            if (usuario == null)
                return NotFound();

            usuario.Nombre = nombre;
            usuario.Apellido = apellido;

            _context.Usuario.Update(usuario);

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/Usuarios/U001
        // Soft delete
        [HttpDelete("{codigo}")]
        public async Task<IActionResult> DeleteUsuario(string codigo)
        {
            var usuario = await (
                from u in _context.Usuario
                where u.Codigo == codigo
                select u
            ).FirstOrDefaultAsync();

            if (usuario == null)
                return NotFound();

            usuario.Estado = "Inactivo";

            _context.Usuario.Update(usuario);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}